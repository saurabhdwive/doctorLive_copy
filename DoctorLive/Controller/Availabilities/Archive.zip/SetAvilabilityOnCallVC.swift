//
//  SetAvilabilityOnCallVC.swift
//  DoctorLive
//
//  Created by call soft on 19/09/21.
//

import UIKit
import RSSelectionMenu
import PromiseKit
class SetAvilabilityOnCallVC: UIViewController {
    
    @IBOutlet weak var fromTime1: UITextField!
    @IBOutlet weak var titleTxt: UILabel!
    @IBOutlet weak var switchButton: UISwitch!
    @IBOutlet weak var toTime1: UITextField!
    @IBOutlet weak var fromAmLable: UITextField!
    @IBOutlet weak var toAmLable: UITextField!
    @IBOutlet weak var fromTime2: UITextField!
    @IBOutlet weak var toTime2: UITextField!
    @IBOutlet weak var slot1Txt: UILabel!
    @IBOutlet weak var slot2Txt: UILabel!
    @IBOutlet weak var fromLbl: UILabel!
    @IBOutlet weak var fromLbl2: UILabel!
    @IBOutlet weak var toLbl2: UILabel!
    @IBOutlet weak var toLbl: UILabel!
    @IBOutlet weak var avilableLbl: UILabel!
    @IBOutlet weak var fromAmLable1: UITextField!
    @IBOutlet weak var toAmLable2: UITextField!
    @IBOutlet weak var dropButton1: UIButton!
    @IBOutlet weak var dropButton2: UIButton!
    @IBOutlet weak var dropButton3: UIButton!
    @IBOutlet weak var dropButton4: UIButton!
    @IBOutlet weak var dropButton5: UIButton!
    @IBOutlet weak var dropButton6: UIButton!
    @IBOutlet weak var dropButton7: UIButton!
    @IBOutlet weak var dropButton8: UIButton!
    @IBOutlet weak var button1View: UIView!
    @IBOutlet weak var saveButton: UIButton!
    var slot1TimeFrom = String()
    var slot2TimeFrom = String()
    var slot1TimeTo = String()
    var slot2TimeTo = String()
    var visitEdit: Bool?
    var callDictSlot1 = [String: String]()
    var callDictSlot2 = [String: String]()
    var slotId: String?
    var avilabilityId: String?
    var avilabilityId1: String?
    var avilability: String?
    var slotCount: Int?
    var avilabilityData = [Slot]()
    var updateAvilabilityData = [Slot1]()
    var timeArray = ["", "1:00", "2:00", "3:00", "4:00", "5:00", "6:00", "7:00", "8:00", "9:00", "10:00", "11:00", "12:00"]
    var amPmArray = ["am", "pm"]
    var slot1SelectedIndex: Int?
    var slot2SelectedIndex: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpView()
        saveButton.layer.cornerRadius = 10
        fromLbl.text = "From".localized()
        toLbl.text = "To".localized()
        fromLbl2.text = "From".localized()
        toLbl2.text = "To".localized()
        avilableLbl.text = "Available".localized()
        titleTxt.text = "Set Availabilities for Call".localized()
        slot1Txt.text = "Slot 1".localized()
        saveButton.setTitle("Save".localized(), for: .normal)
        slot2Txt.text = "Slot 2".localized()
        if slotCount != 0 {
            self.fromTime1.text = callDictSlot1["slot1From"] ?? ""
            self.fromTime2.text = callDictSlot2["slot2From"] ?? ""
            self.toTime1.text = callDictSlot1["slot1To"] ?? ""
            self.toTime2.text = callDictSlot2["slot2To"] ?? ""
            fromAmLable.text = callDictSlot1["slot1FromAm"] ?? ""
            toAmLable.text = callDictSlot1["slot1ToAm"] ?? ""
            fromAmLable1.text = callDictSlot2["slot2FromAm"] ?? ""
            toAmLable2.text = callDictSlot2["slot2ToAm"] ?? ""
        }
    }
    
    func setUpView() {
        EditingTextField()
    }
    
    func EditingTextField() {
        [dropButton1, dropButton2,dropButton3,dropButton4,dropButton5,dropButton6,dropButton7,dropButton8].forEach({ text in
            text?.layer.borderWidth = 1
            text?.layer.cornerRadius = 8
            text?.layer.borderColor = UIColor.gray.cgColor
        })
    }
    
    @IBAction func dropButton1Tapped(_ sender: Any) {
        let data: [String] = timeArray
        var selectedNames: [String] = []
        let menu = RSSelectionMenu(selectionStyle: .single, dataSource: data) { (cell, name, indexPath) in
            cell.textLabel?.text = name
            
        }
        menu.cellSelectionStyle = .tickmark
        menu.setSelectedItems(items: selectedNames) { (name, index, selected, selectedItems) in
            self.slot1SelectedIndex = index + 1
            
            selectedNames = selectedItems
            //let items = selectedNames.joined(separator:", ")
            self.fromTime1.text = name
            self.dismiss(animated: true, completion: nil)
        }
        menu.show(style: .popover(sourceView: sender as! UIView, size: CGSize(width: button1View.frame.width, height: view.frame.height - 200), arrowDirection: .any, hideNavBar: true), from: self)
    }
    
    @IBAction func dropButton2Tapped(_ sender: Any) {
        let data: [String] = amPmArray
        var selectedNames: [String] = []
        let menu = RSSelectionMenu(selectionStyle: .single, dataSource: data) { (cell, name, indexPath) in
            cell.textLabel?.text = name
        }
        menu.cellSelectionStyle = .tickmark
        menu.setSelectedItems(items: selectedNames) { (name, index, selected, selectedItems) in
            selectedNames = selectedItems
            //let items = selectedNames.joined(separator:", ")
            self.fromAmLable.text = name
            self.dismiss(animated: true, completion: nil)
            
        }
        menu.show(style: .popover(sourceView: sender as! UIView, size: CGSize(width: button1View.frame.width, height: 110), arrowDirection: .up, hideNavBar: true), from: self)
    }
    
    @IBAction func dropButton3Tapped(_ sender: Any) {
       // let arraySlice = timeArray.suffix(from: slot1SelectedIndex ?? 0)
        let arraySlice = timeArray
        let data: [String] = Array(arraySlice)
        var selectedNames: [String] = []
        let menu = RSSelectionMenu(selectionStyle: .single, dataSource: data) { (cell, name, indexPath) in
            cell.textLabel?.text = name
        }
        menu.cellSelectionStyle = .tickmark
        menu.setSelectedItems(items: selectedNames) { (name, index, selected, selectedItems) in
            selectedNames = selectedItems
            self.toTime1.text = name
            self.dismiss(animated: true, completion: nil)
        }
        menu.show(style: .popover(sourceView: sender as! UIView, size: CGSize(width: button1View.frame.width, height: view.frame.height - 200), arrowDirection: .up, hideNavBar: true), from: self)
    }
    
    @IBAction func dropButton4Tapped(_ sender: Any) {
        let data: [String] = amPmArray
        var selectedNames: [String] = []
        let menu = RSSelectionMenu(selectionStyle: .single, dataSource: data) { (cell, name, indexPath) in
            cell.textLabel?.text = name
        }
        menu.cellSelectionStyle = .tickmark
        menu.setSelectedItems(items: selectedNames) { (name, index, selected, selectedItems) in
            selectedNames = selectedItems
            
            self.toAmLable.text = name
            self.dismiss(animated: true, completion: nil)
            
        }
        menu.show(style: .popover(sourceView: sender as! UIView, size: CGSize(width: button1View.frame.width, height: 110), arrowDirection: .up, hideNavBar: true), from: self)
    }
    
    @IBAction func dropButton5Tapped(_ sender: Any) {
        let data: [String] = timeArray
        var selectedNames: [String] = []
        let menu = RSSelectionMenu(selectionStyle: .single, dataSource: data) { (cell, name, indexPath) in
            cell.textLabel?.text = name
        }
        menu.cellSelectionStyle = .tickmark
        menu.setSelectedItems(items: selectedNames) { (name, index, selected, selectedItems) in
            self.slot2SelectedIndex = index + 1
            selectedNames = selectedItems
            self.fromTime2.text = name
            self.dismiss(animated: true, completion: nil)
        }
        menu.show(style: .popover(sourceView: sender as! UIView, size: CGSize(width: button1View.frame.width, height: view.frame.height - 200), arrowDirection: .up, hideNavBar: true), from: self)
    }
    
    @IBAction func saveButtonTapped(_ sender: Any) {
        if slotCount != 0 {
            if switchButton.isOn {
            if self.fromTime1.text?.isEmpty ?? false {
                AppToast.showMessage1(message: "Please Select Time", self)
            } else if fromAmLable.text?.isEmpty ?? false {
                AppToast.showMessage1(message: "Please Select Am/Pm", self)
            } else if self.toTime1.text?.isEmpty ?? false {
                AppToast.showMessage1(message: "Please Select Time", self)
            } else if toAmLable.text?.isEmpty ?? false {
                AppToast.showMessage1(message: "Please Select Am/Pm", self)
            }else{
                self.performUpdateAvilability()
            }
            } else {
                self.performUpdateAvilability()
            }
        } else {
            if switchButton.isOn {
            if self.fromTime1.text?.isEmpty ?? false {
                AppToast.showMessage1(message: "Please Select Time", self)
            } else if fromAmLable.text?.isEmpty ?? false {
                AppToast.showMessage1(message: "Please Select Am/Pm", self)
            } else if self.toTime1.text?.isEmpty ?? false {
                AppToast.showMessage1(message: "Please Select Time", self)
            } else if toAmLable.text?.isEmpty ?? false {
                AppToast.showMessage1(message: "Please Select Am/Pm", self)
            }else{
                performGetAvilability()
            }
            } else {
                self.performUpdateAvilability()
            }
        
        }
    }
    
    @IBAction func dropButton6Tapped(_ sender: Any) {
        let arraySlice = timeArray.suffix(from: slot2SelectedIndex ?? 0)
        let data: [String] = Array(arraySlice)
        var selectedNames: [String] = []
        let menu = RSSelectionMenu(selectionStyle: .single, dataSource: data) { (cell, name, indexPath) in
            cell.textLabel?.text = name
        }
        menu.cellSelectionStyle = .tickmark
        menu.setSelectedItems(items: selectedNames) { (name, index, selected, selectedItems) in
            selectedNames = selectedItems
            //let items = selectedNames.joined(separator:", ")
            self.toTime2.text = name
            self.dismiss(animated: true, completion: nil)
            
        }
        menu.show(style: .popover(sourceView: sender as! UIView, size: CGSize(width: button1View.frame.width, height: view.frame.height - 200), arrowDirection: .up, hideNavBar: true), from: self)
    }
    
    @IBAction func dropButton7Tapped(_ sender: Any) {
        let data: [String] = amPmArray
        var selectedNames: [String] = []
        let menu = RSSelectionMenu(selectionStyle: .single, dataSource: data) { (cell, name, indexPath) in
            cell.textLabel?.text = name
        }
        menu.cellSelectionStyle = .tickmark
        menu.setSelectedItems(items: selectedNames) { (name, index, selected, selectedItems) in
            selectedNames = selectedItems
            //let items = selectedNames.joined(separator:", ")
            self.fromAmLable1.text = name
            self.dismiss(animated: true, completion: nil)
            
        }
        menu.show(style: .popover(sourceView: sender as! UIView, size: CGSize(width: button1View.frame.width, height: 110), arrowDirection: .up, hideNavBar: true), from: self)
    }
    
    @IBAction func dropButton8Tapped(_ sender: Any) {
        let data: [String] = amPmArray
        var selectedNames: [String] = []
        let menu = RSSelectionMenu(selectionStyle: .single, dataSource: data) { (cell, name, indexPath) in
            cell.textLabel?.text = name
        }
        menu.cellSelectionStyle = .tickmark
        menu.setSelectedItems(items: selectedNames) { (name, index, selected, selectedItems) in
            selectedNames = selectedItems
            //let items = selectedNames.joined(separator:", ")
            self.toAmLable2.text = name
            self.dismiss(animated: true, completion: nil)
            
        }
        menu.show(style: .popover(sourceView: sender as! UIView, size: CGSize(width: button1View.frame.width, height: 110), arrowDirection: .up, hideNavBar: true), from: self)
    }
    
    @IBAction func switchButtonTapped(_ sender: UISwitch) {
        if (sender.isOn) {
            enableButton()
            self.avilability = "1"
        } else {
            disableButton()
            self.avilability = "0"
            clearTxt()
        }
    }
    
    @IBAction func notification(_ sender: Any) {
        let vc = NotificationViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func backButtonTapped(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
//        let vc = DayAvilabilityVC()
//        vc.setav = true
////        vc.modalPresentationStyle = .fullScreen
////        vc.modalTransitionStyle = .crossDissolve
//        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func disableButton(){
        [dropButton1, dropButton2,dropButton3,dropButton4,dropButton5,dropButton6,dropButton7,dropButton8].forEach({ text in
            text?.isEnabled = false
            //text?.layer.borderColor = UIColor.gray.cgColor
        })
    }
    
    func clearTxt(){
        [fromTime1, fromTime2,toTime1,toTime2,fromAmLable,toAmLable,fromAmLable1,toAmLable2].forEach({ text in
            text?.text = ""
            //text?.layer.borderColor = UIColor.gray.cgColor
        })
    }
    
    func enableButton(){
        [dropButton1, dropButton2,dropButton3,dropButton4,dropButton5,dropButton6,dropButton7,dropButton8].forEach({ text in
            text?.isEnabled = true
        })
    }
}

extension SetAvilabilityOnCallVC {
    func getAvilabilityList(param:[String:Any]?){
        //Loader.show()
        ApiManager.instance.fetchApiService(method: .post, url: APIEndpoint.createBooking, passDict: param, header: ApiManager.instance.getHeadeWithJwtToken())  { (result) in
            DispatchQueue.main.async {
                //Loader.hide()
            }
            switch result{
            case .success(let data):
                let modelData = try? JSONDecoder().decode(AvililabilityListModel.self, from: data)
                print(modelData!)
                let view = UIStoryboard.init(name: "Auth", bundle: nil)
                let vc = view.instantiateViewController(withIdentifier: "DayAvilabilityVC") as! DayAvilabilityVC
                vc.slotSet = true
                vc.setav = true
                self.navigationController?.pushViewController(vc, animated: true)
               
//                vc.modalPresentationStyle = .fullScreen
//                vc.modalTransitionStyle = .crossDissolve
//                self.present(vc, animated: true, completion: nil)
                
                break
            case .failure(let error):
                print("error.........\(error.localizedDescription)")
                // self.errorMessage(error.localizedDescription)
                break
            }
        }
    }
    
    func performGetAvilability() {
        let slot1From = fromTime1.text ?? ""
        let fromAmLable = fromAmLable.text ?? ""
        let toAmLable = toAmLable.text ?? ""
        let slot2From = fromTime2.text ?? ""
        let slot1To = toTime1.text ?? ""
        let slot2To = toTime2.text ?? ""
        let fromAmLable1 = fromAmLable1.text ?? ""
        let toAmLable1 = toAmLable2.text ?? ""
        let id = UserDefaults.standard.string(forKey: Constants.userId)
        self.avilabilityData.append(Slot(slot: "1", clinicName: "", slotFrom: "\(slot1From)\(fromAmLable)", slotTo: "\(slot1To)\(toAmLable)", availability: self.avilability ?? "1"))
        self.avilabilityData.append(Slot(slot: "2", clinicName: "", slotFrom: "\(slot2From)\(fromAmLable1)", slotTo: "\(slot2To)\(toAmLable1)", availability: self.avilability ?? "1"))
        var slotArray = [[String:Any]]()
        self.avilabilityData.forEach { slot in
            slotArray.append(["slot":"\(slot.slot)","clinic_name":"\(slot.clinicName)","slot_from":"\(slot.slotFrom)","slot_to":"\(slot.slotTo)","availability":"\(slot.availability)"])
        }
        var parameter = [String: Any]()
        guard let code = UserDefaults.standard.string(forKey: Constants.languageCode) else { return }
        parameter = ["language_type": code,
                     "doctor_id": "\(id ?? "")",
                     "id": slotId ?? "",
                     "slot": slotArray]
        getAvilabilityList(param: parameter)
    }}


extension SetAvilabilityOnCallVC {
    func getUpdateList(param:[String:Any]?) {
        //Loader.show()
        ApiManager.instance.fetchApiService(method: .post, url: APIEndpoint.updateAvilability, passDict: param, header: ApiManager.instance.getHeadeWithJwtToken())  { (result) in
            DispatchQueue.main.async {
                //Loader.hide()
            }
            switch result {
            case .success(let data):
                let modelData = try? JSONDecoder().decode(UpdateAvilabilityModel.self, from: data)
                print(modelData!)
                let view = UIStoryboard.init(name: "Auth", bundle: nil)
                let vc = view.instantiateViewController(withIdentifier: "DayAvilabilityVC") as! DayAvilabilityVC
                vc.slotSet = true
                vc.setav = true
              //  self.navigationController?.pushViewController(vc, animated: true)
               
//                let vc = DayAvilabilityVC()
//                vc.slotSet = true
//                vc.setav = true
                vc.modalPresentationStyle = .fullScreen
                vc.modalTransitionStyle = .crossDissolve
                self.navigationController?.pushViewController(vc, animated: true)
        //    self.present(vc, animated: true, completion: nil)
                break
            case .failure(let error):
                print("error.........\(error.localizedDescription)")
                
                break
            }
        }
    }
    
    func performUpdateAvilability() {
        let slot1From = fromTime1.text ?? ""
        let fromAmLable = fromAmLable.text ?? ""
        let toAmLable = toAmLable.text ?? ""
        let slot2From = fromTime2.text ?? ""
        let slot1To = toTime1.text ?? ""
        let slot2To = toTime2.text ?? ""
        let fromAmLable1 = fromAmLable1.text ?? ""
        let toAmLable1 = toAmLable2.text ?? ""
        guard let code = UserDefaults.standard.string(forKey: Constants.languageCode) else { return }
        self.updateAvilabilityData.append(Slot1(id: Int(avilabilityId ?? "") ?? 0, slot: "1", clinicName: "",slotFrom: "\(slot1From)\(fromAmLable)", slotTo: "\(slot1To)\(toAmLable)", availability: self.avilability ?? "1"))
        self.updateAvilabilityData.append(Slot1(id: Int(avilabilityId1 ?? "") ?? 0, slot: "2", clinicName: "", slotFrom: "\(slot2From)\(fromAmLable1)", slotTo: "\(slot2To)\(toAmLable1)", availability: self.avilability ?? "1"))
        var slotArray = [[String:Any]]()
        self.updateAvilabilityData.forEach { slot in
            slotArray.append(["id":  slot.id, "slot":"\(slot.slot)","clinic_name":"\(slot.clinicName)","slot_from":"\(slot.slotFrom)","slot_to":"\(slot.slotTo)","availability":"\(slot.availability)"])
        }
        var parameter = [String: Any]()
        parameter = ["language_type": code,
                     "availability_id": slotId ?? "",
                     "slots": slotArray]
        getUpdateList(param: parameter)
    }
}

extension String {
    func maxLength(length: Int) -> String {
        var str = self
        let nsString = str as NSString
        if nsString.length >= length {
            str = nsString.substring(with:
                                        NSRange(
                                            location: 0,
                                            length: nsString.length > length ? length : nsString.length)
            )
        }
        return  str
    }
}
